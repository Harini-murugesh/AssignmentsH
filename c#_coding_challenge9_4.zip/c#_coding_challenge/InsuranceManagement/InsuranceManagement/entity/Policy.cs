﻿namespace entity
{
    public class Policy
    {
        private int policyId;
        private string policyName;
        private int policyTerm;

        public Policy() { }

        public Policy(int policyId, string policyName, int policyTerm)
        {
            this.policyId = policyId;
            this.policyName = policyName;
            this.policyTerm = policyTerm;
        }

        public int PolicyId
        {
            get { return policyId; }
            set { policyId = value; }
        }

        public string PolicyName
        {
            get { return policyName; }
            set { policyName = value; }
        }

        public int PolicyTerm
        {
            get { return policyTerm; }
            set { policyTerm = value; }
        }

        public override string ToString()
        {
            return $"PolicyId: {policyId}, Name: {policyName}, Term: {policyTerm} months";
        }
    }
}
