﻿using System;

namespace entity
{
    public class Claim
    {
        private int claimId;
        private string claimNumber;
        private DateTime dateFiled;
        private decimal claimAmount;
        private string status;
        private Policy policy;
        private Client client;

        public Claim() { }

        public Claim(int claimId, string claimNumber, DateTime dateFiled, decimal claimAmount, string status, Policy policy, Client client)
        {
            this.claimId = claimId;
            this.claimNumber = claimNumber;
            this.dateFiled = dateFiled;
            this.claimAmount = claimAmount;
            this.status = status;
            this.policy = policy;
            this.client = client;
        }

        public int ClaimId { get { return claimId; } 
            set { claimId = value; } }
        public string ClaimNumber { get { return claimNumber; }
            
            set { claimNumber = value; } }
        public DateTime DateFiled { get { return dateFiled; } 
            set { dateFiled = value; } }
        public decimal ClaimAmount { get { return claimAmount; } set { claimAmount = value; } }
        public string Status { get { return status; } 
            set { status = value; } }
        public Policy Policy { get { return policy; }
            set { policy = value; } }
        public Client Client { get { return client; }
            set { client = value; } }

        public override string ToString()
        {
            return $"ClaimId: {claimId}, Number: {claimNumber}, DateFiled: {dateFiled.ToShortDateString()}, Amount: {claimAmount}, Status: {status}, Policy: [{policy}], Client: [{client}]";
        }
    }
}
