﻿using System.Data.SqlClient;
using util;

namespace util
{

    public static class DBConnection
    {
        private static SqlConnection connection;

        public static SqlConnection GetConnection()
        {
            if (connection == null)
            {
                string connectionString = "Server=(local)\\SQLEXPRESS;Database=InsuranceDB;Trusted_Connection=True;";
                connection = new SqlConnection(connectionString);
            }
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open(); 
            }
            return connection;
        }
    }
}