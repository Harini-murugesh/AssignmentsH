﻿namespace util
{
    public class PropertyUtil
    {
        public static string GetPropertyString()
        {
            string server = "(local)\\SQLEXPRESS"; 
            string database = "InsuranceDB";

            return $"Server={server};Database={database};Trusted_Connection=True;";
        }
    }
}
