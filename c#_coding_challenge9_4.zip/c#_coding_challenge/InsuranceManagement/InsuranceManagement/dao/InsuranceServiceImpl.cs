﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using entity;
using util;

namespace dao
{
    public class InsuranceServiceImpl : IPolicyService
    {
        private SqlConnection connection;

        public InsuranceServiceImpl()
        {
            connection = DBConnection.GetConnection();
        }

        public bool CreatePolicy(Policy policy)
        {
            try
            {
                string query = "INSERT INTO Policies (policyId, policyName, policyTerm) VALUES (@id, @name, @term)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", policy.PolicyId);
                cmd.Parameters.AddWithValue("@name", policy.PolicyName);
                cmd.Parameters.AddWithValue("@term", policy.PolicyTerm);

                int rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating policy: " + ex.Message);
                return false;
            }
        }

        public Policy GetPolicy(int policyId)
        {
            try
            {
                string query = "SELECT * FROM Policies WHERE policyId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", policyId);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Policy policy = new Policy(
                        Convert.ToInt32(reader["policyId"]),
                        reader["policyName"].ToString(),
                        Convert.ToInt32(reader["policyTerm"])
                    );
                    reader.Close();
                    return policy;
                }
                reader.Close();
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error fetching policy: " + ex.Message);
                return null;
            }
        }

        public List<Policy> GetAllPolicies()
        {
            List<Policy> policies = new List<Policy>();
            try
            {
                string query = "SELECT * FROM Policies";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    policies.Add(new Policy(
                        Convert.ToInt32(reader["policyId"]),
                        reader["policyName"].ToString(),
                        Convert.ToInt32(reader["policyTerm"])
                    ));
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error fetching all policies: " + ex.Message);
            }
            return policies;
        }

        public bool UpdatePolicy(Policy policy)
        {
            try
            {
                string query = "UPDATE Policies SET policyName = @name, policyTerm = @term WHERE policyId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", policy.PolicyId);
                cmd.Parameters.AddWithValue("@name", policy.PolicyName);
                cmd.Parameters.AddWithValue("@term", policy.PolicyTerm);

                int rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating policy: " + ex.Message);
                return false;
            }
        }

        public bool DeletePolicy(int policyId)
        {
            try
            {
                string query = "DELETE FROM Policies WHERE policyId = @id";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@id", policyId);

                int rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting policy: " + ex.Message);
                return false;
            }
        }
    }
}
