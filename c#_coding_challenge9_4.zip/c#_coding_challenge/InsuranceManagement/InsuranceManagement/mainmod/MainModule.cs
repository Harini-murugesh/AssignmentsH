﻿using System;
using dao;
using entity;
using myexceptions;

namespace mainmod
{
    class MainModule
    {
        static void Main(string[] args)
        {
            InsuranceServiceImpl service = new InsuranceServiceImpl();

            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n--- Insurance Policy Management ---");
                Console.WriteLine("1. Create Policy");
                Console.WriteLine("2. Get Policy by ID");
                Console.WriteLine("3. View All Policies");
                Console.WriteLine("4. Update Policy");
                Console.WriteLine("5. Delete Policy");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            Console.Write("Enter Policy ID: ");
                            int newId = int.Parse(Console.ReadLine());
                            Console.Write("Enter Policy Name: ");
                            string name = Console.ReadLine();
                            Console.Write("Enter Coverage Amount: ");
                            double amount = double.Parse(Console.ReadLine());

                            Policy newPolicy = new Policy(newId, name,(int)amount);
                            bool created = service.CreatePolicy(newPolicy);
                            Console.WriteLine(created ? "Policy created successfully!" : "Failed to create policy.");
                            break;

                        case "2":
                            Console.Write("Enter Policy ID to retrieve: ");
                            int searchId = int.Parse(Console.ReadLine());
                            Policy foundPolicy = service.GetPolicy(searchId);
                            Console.WriteLine("Policy Found: " + foundPolicy);
                            break;

                        case "3":
                            var allPolicies = service.GetAllPolicies();
                            Console.WriteLine("All Policies:");
                            foreach (var policy in allPolicies)
                            {
                                Console.WriteLine(policy);
                            }
                            break;

                        case "4":
                            Console.Write("Enter Policy ID to update: ");
                            int updateId = int.Parse(Console.ReadLine());
                            Console.Write("Enter New Policy Name: ");
                            string newName = Console.ReadLine();
                            Console.Write("Enter New Coverage Amount: ");
                            double newAmount = double.Parse(Console.ReadLine());

                            Policy updatedPolicy = new Policy(updateId, newName, (int)newAmount);
                            bool updated = service.UpdatePolicy(updatedPolicy);
                            Console.WriteLine(updated ? "Policy updated successfully!" : "Update failed.");
                            break;

                        case "5":
                            Console.Write("Enter Policy ID to delete: ");
                            int deleteId = int.Parse(Console.ReadLine());
                            bool deleted = service.DeletePolicy(deleteId);
                            Console.WriteLine(deleted ? "Policy deleted successfully!" : "Deletion failed.");
                            break;

                        case "6":
                            exit = true;
                            Console.WriteLine("Exiting...");
                            break;

                        default:
                            Console.WriteLine("Invalid choice. Try again.");
                            break;
                    }
                }
                catch (PolicyNotFoundException ex)
                {
                    Console.WriteLine("Policy Error: " + ex.Message);
                }
                catch (FormatException)
                {
                    Console.WriteLine("Input format error. Please enter valid numbers.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected error: " + ex.Message);
                }
            }
        }
    }
}
