﻿using System;

namespace myexceptions
{
    public class PolicyNotFoundException : Exception
    {
        public PolicyNotFoundException() : base("Policy not found!") { }

        public PolicyNotFoundException(string message) : base(message) { }
    }
}
